#modulo
#funciones
def produc():
    productos = []
    cantidad = int(input("Ingrese la cantidad de productos a ingresar :"))
    print("La cantidad de productos ingresada es: ", cantidad)
    for i in range(cantidad):
        po = input("Ingrese el producto: ")
        productos.append(po)
        i+=1
    for k in productos:
       print("Los productos son: ", k)

def añadir():
    products = []
    for x in products:
        print (x)
        print(len(products))

    products.append(input("digite un nuevo producto "))

    for x in products:
        print (x)
        print(len(products))