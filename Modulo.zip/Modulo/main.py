import funciones


cantidad = int(input("Ingrese la cantidad de productos a ingresar :"))
print("La cantidad de productos ingresada es: ", cantidad)
for i in range(cantidad):
        producto = input("Ingrese el producto: ")
for k in producto:
     print("Los productos son: ", k)
print (funciones.producs)


productis = []
for x in productis:
        print (x)
        print(len(productis))

productis.append(input("digite un nuevo producto "))

for x in productis:
        print (x)
        print(len(productis))
print (funciones.añadir)